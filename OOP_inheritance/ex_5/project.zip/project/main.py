from project.dog import Dog
from project.cat import Cat

d = Dog()
c = Cat()

print(d.bark())
print(d.eat())
print(c.meow())
print(c.eat())