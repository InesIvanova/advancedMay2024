from project.fruit import Fruit


f = Fruit("apple", "2024-07-12")
print(f.name)
print(f.expiration_date)